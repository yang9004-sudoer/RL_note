import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__() # python2 style
        self.conv1 = nn.Conv2d(1, 6, 3)
        self.conv2 = nn.Conv2d(6, 16, 3)

        self.fc1 = nn.Linear(16 * 6 *6, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)
        x = x.view(-1, self.num_flat_features(x))

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x) # no using of softmax ?
        return x

    def num_flat_features(self, x):
        size = x.size()[1: ]
        num_features = 1
        for s in size:
            num_features *= s
        return num_features


net = Net()
print (net)

# params = list(net.parameters())
#
#
# for p in params:
#     print (p.size())
#
# input = torch.randn(1, 1, 32, 32)
# print ("input : " , input.shape)
# print ("input unsqueeze : " , input.unsqueeze(0).shape)
# out = net(input)
# print (out)
#
# net.zero_grad()
# out.backward(torch.randn(1, 10))
#
# print (out)
# torch.nn
# nSamples * nChannels * Height * Width
# input.unsqueeze(0)

input = torch.randn(1, 1, 32, 32)
out = net(input)
print(out)

output = net(input)
target = torch.randn(10)
target = target.view(1, -1)

crierion = nn.MSELoss()
loss = crierion(output, target)
print(loss)

print("before the loss backward ", list(net.parameters())[0].grad)
loss.backward()

print ('conv1.bias.grad init ?')
print (net.conv1.bias.grad)

net.zero_grad() # zeros the gradient buffers of all parameters

print ('conv1.bias.grad init after ?')
print (net.conv1.bias.grad)

optimizer = optim.SGD(net.parameters(), lr=0.01)

optimizer.zero_grad()
output = net(input)
loss = crierion(output, target) # calculate the loss of net
loss.backward() # calculate the gradient

print(list(net.parameters())[0].grad)

print (type(net.parameters()))
optimizer.step() # does the update
