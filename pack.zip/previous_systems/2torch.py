import torch

if torch.cuda.is_available():
    device = torch.device("cuda")


# x = torch.ones(2, 2, requires_grad=True)
x = torch.ones(2, 2, requires_grad=False)
x = x.to(device)
print (x)

y = x + 1
print (y)
y.requires_grad_(True)

# only tensor created by function has the grad_fn
# tensors created by the user doesn't have grad_fn

print (y.grad_fn)

z = y * y * 3

out = z.mean()

print (z, out)

out.backward()

print("y.grad :" , y.grad) # y.grad is same as x