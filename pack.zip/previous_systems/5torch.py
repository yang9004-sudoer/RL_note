import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T

import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

fc = nn.Linear(40, 3);

def run():
    input = torch.randn(40).unsqueeze(0) # single sample
    inputs = torch.randn(30, 40) # batch = 3
    output = fc.forward(input)
    outputs = fc.forward(inputs)

    print (output.shape)
    print (outputs.shape)

    pass


if __name__ == '__main__':
    run()