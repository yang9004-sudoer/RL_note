import torch
import numpy

# construct a 5*3 matrix , uninitalized
x = torch.empty(5, 3)

#
print (x)

# Construct a randomly

y = torch.rand(5 , 3)
print (y)

yn = y.new_ones(5, 3, dtype = torch.double)
print (yn)
print (y)

nt = numpy.ones((5, 7))
t = torch.tensor([5.5, 3])

# when x is a tensor

print (x.size())
z = torch.empty(5 ,3)
print (z)

print (z[: , 1])

# if want to resize / reshape tensors ,

x = torch.randn(4, 4)
print (x)
y = x.view(16)
z = x.view(-1, 8)
print (y)
print (z)
print (x.size(), y.size(), z.size())

x = torch.randn(1 ,5)
print (x)
# print (x.item())
# if have a one element tensor, use. item()
# to get the value as a Python number

a = torch.ones(5)
print (a)

# tensor () difference

b = a.numpy()
print (b)

if torch.cuda.is_available():
    device = torch.device("cuda")
    y = torch.ones_like(x, device=device)
    x = x.to(device)
    z = x + y
    print (z)
    print (z.to("cpu", torch.double))