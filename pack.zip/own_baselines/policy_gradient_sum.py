import torch
import torch.nn as nn
from torch.distributions.categorical import Categorical
import numpy as np
import gym
import torch.nn.functional as F




class mlp_based_PG(nn.Module):

    def __init__(self, input_dim, layers_dims, output_dim):
        super(mlp_based_PG, self).__init__()

        self.layers = []
        self.layers.append(input_dim)
        self.layers.extend(layers_dims)
        self.layers.append(output_dim)

        self.nn_layers = []
        for i in range(len(self.layers)-1):
            name = 'fc' + str(i)
            # add to named children modules
            self.add_module(name, nn.Linear(self.layers[i], self.layers[i+1]))


    def forward(self, x):
        # for loop in neural network structure
        for layer in list(self.children())[:-1]:
            x = torch.tanh(layer(x))
        # for last output using softmax and logit ?
        x = list(self.children())[-1](x)
        return x

    def getCategorical(self, x):
        log_prob_x = self.forward(x)
        return Categorical(logits=log_prob_x)



def run():
    # just train for network
    #########
    max_epochs = 2000
    nn_structure = []

    env = gym.make('CartPole-v0')
    render_flag = False # need screen rendering ?
    obs_dim = env.observation_space.shape[0]
    n_acts = env.action_space.n
    print (obs_dim)
    print (n_acts)
    # builld mlp-based nn policy agent based on env info

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    pg_agent = mlp_based_PG(obs_dim, [300], n_acts).to(device)

    print ('pg_agent parameters ')
    print (len(list(pg_agent.parameters())))

    # make optimizer
    optimizer = torch.optim.Adam(pg_agent.parameters(), lr=1e-2)
    batch_size = 3000

    #############

    for i in range(max_epochs):
        # each epochs
        batch_obs = []
        batch_acts = []
        batch_weights = []
        batch_rets = []
        batch_lens = []

        # reset episode - specific
        obs = env.reset() # init obs
        done = False
        ep_rews = []

        while True: # for while for single episode

            # rendering flag
            if (render_flag):
                env.render()

            # save obs
            batch_obs.append(obs.copy())

            # behavior action
            # sampling from distribution, using Categorical
            act = pg_agent.getCategorical(
                torch.tensor(obs, dtype=torch.float32, device=device)).sample().item()
            obs, rew, done, _ = env.step(act)

            batch_acts.append(act)
            ep_rews.append(rew)

            if done:
                ep_ret, ep_len = sum(ep_rews), len(ep_rews)
                batch_rets.append(ep_ret)
                batch_lens.append(ep_len)
                batch_weights += [ep_ret] * ep_len

                # reset episode-specific variables
                obs, done, ep_rews = env.reset(), False, []

                # merge mutliple single episodes into one batch if
                if len(batch_obs) > batch_size:
                    break

            pass
        # finish this episode
        optimizer.zero_grad()

        # when you have enough batch size data
        tensor_obs = torch.tensor(batch_obs, dtype=torch.float32, device=device)
        tensor_acts = torch.tensor(batch_acts, dtype=torch.long, device=device)
        tensor_weights = torch.tensor(batch_weights, dtype=torch.float32, device=device)

        # compute loss
        # log_prob
        # value = value.long().unsqueeze(-1)
        #         value, log_pmf = torch.broadcast_tensors(value, self.logits)
        #         value = value[..., :1]
        #         return log_pmf.gather(-1, value).squeeze(-1)

        # logp1 = pg_agent.getCategorical(tensor_obs).log_prob(tensor_acts)
        # print (logp1)
        #total_loss = -(logp*tensor_weights).mean()
        # logp = pg_agent(tensor_obs) # directly get log_prob
        # print ('original output as logits? ' , logp)
        # print ('correct logits output ', pg_agent.getCategorical(tensor_obs).logits)

        logp = pg_agent.getCategorical(tensor_obs).logits
        logp_acts = logp.gather(-1, tensor_acts.unsqueeze(-1)).squeeze(-1) # pick each log prob by action values

        # print (logp_acts.shape)
        # using negative sum then we can use gradient descent algorithm
        total_loss = -(logp_acts * tensor_weights).mean()
        print ('current update total losss : ',total_loss)
        total_loss.backward()
        optimizer.step()
        print ('epoch: %d total_loss: %.3f average_return_reward_sofar %.3f ep_len: %.3f'%
               (i, total_loss, np.mean(batch_rets), np.mean(batch_lens)))

        # input()
        pass


    pass

if __name__ == '__main__':
    run()