# -*- coding: utf-8 -*-

import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
from itertools import count
from PIL import Image

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T

import time

# global hyper-parameters
batch_size = 128  # bigger batch
gamma = 0.99
eps = 1.0
eps_end = 0.05
eps_decay = 100
target_update = 100

# if gpu is to be used
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# set up matplotlib
is_ipython = 'inline' in matplotlib.get_backend()
if is_ipython:
    from IPython import display

plt.ion()

Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward'))


class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.position = 0
        self.aver = 0
        self.memory = []

    def push(self, *args):
        """Saves a transition."""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity
        pass

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)


class DQN(nn.Module):
    # update network architecture for Neural Network
    # archiectrue [4, 300, 300, 2]
    def __init__(self, state_dim, n1, n2, output_dim):
        super(DQN, self).__init__()
        # dynamic layer
        self.fc1 = nn.Linear(state_dim, n1)
        self.fc2 = nn.Linear(n1, n2)
        self.fc3 = nn.Linear(n2, output_dim)
        self.n_actions = output_dim
        self.steps_done = 0

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)  # evaluate the Q(s,a) based on
        return x  # (batch, output_dim)

    def select_action(self, state, eps):
        steps_done = self.steps_done
        sample = random.random()  # sampling from [0,1]
        # eps_threshold = eps
        eps *= 0.995
        eps_threshold = max(eps_end, eps)
        self.steps_done += 1
        if sample > eps_threshold:
            with torch.no_grad():
                # self.forward(torch.from_numpy(state).to(device)).max(1)[1].view(1, 1)
                # state_n = torch.tensor(state).float()
                acts = self.forward(state)
                # max oper -> (values, indices)
                return acts.max(1)[1].view(1, 1)
                # return self.forward(state_n)
        else:
            return torch.tensor([[random.randrange(self.n_actions)]], device=device, dtype=torch.long)


def report(fw, info):
    fw.write(str(info + "\n"))


def optimize_model(memory, policy_net, target_net, optimizer, useTargetNet):
    if len(memory) < batch_size:
        return
    # sampling transitions
    transitions = memory.sample(batch_size)
    batch = Transition(*zip(*transitions))

    non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                            batch.next_state)), device=device, dtype=torch.bool)
    non_final_next_states = torch.cat([s for s in batch.next_state
                                       if s is not None])

    state_batch = torch.cat(batch.state)
    action_batch = torch.cat(batch.action)
    reward_batch = torch.cat(batch.reward)

    state_action_values = policy_net(state_batch).gather(1, action_batch)

    next_state_values = torch.zeros(batch_size, device=device, dtype=torch.double)

    if useTargetNet: # the target is randomly initlized until 1000000 update
        # print ('using target net ... ')
        # next_state_values[non_final_mask] = target_net(non_final_next_states).max(1)[0].detach()
        next_state_values[non_final_mask] = policy_net(non_final_next_states).max(1)[0].detach()
    else:
        # print ('using policy net ...')
        # next_state_values[non_final_mask] = target_net(non_final_next_states).max(1)[0].detach()
        next_state_values[non_final_mask] = policy_net(non_final_next_states).max(1)[0].detach()


    expected_state_action_values = (next_state_values * gamma) + reward_batch
    
    # check loss
    loss = F.smooth_l1_loss(state_action_values, expected_state_action_values.unsqueeze(1))
    # loss = F.mse_loss(state_action_values, expected_state_action_values.unsqueeze(1))

    # Optimize the model
    optimizer.zero_grad()
    loss.backward()
    #for param in policy_net.parameters():
    #    param.grad.data.clamp_(-1, 1) /? clamp?
    optimizer.step()

    pass


def plot_durations(episode_durations):
    plt.figure(2)
    plt.clf()
    durations_t = torch.tensor(episode_durations, dtype=torch.float)
    plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(durations_t.numpy())
    # Take 100 episode averages and plot them too
    if len(durations_t) >= 100:
        means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
        means = torch.cat((torch.zeros(99), means))
        plt.plot(means.numpy())

    plt.pause(0.001)  # pause a bit so that plots are updated
    if is_ipython:
        display.clear_output(wait=True)
        display.display(plt.gcf())


def run():
    # setup the report file
    # fo = open("report_" + time.asctime().replace(" ", "_") + ".txt", "w")
    # environment control
    env = gym.make('CartPole-v0').unwrapped
    # report(fo, 'CartPole-v0')

    # display setup
    is_ipython = 'inline' in matplotlib.get_backend()
    if is_ipython:
        from IPython import display
    plt.ion()

    # training ()
    # create an current Q-networks
    # create an target Q-networks
    #
    policy_net = DQN(4, 300, 300, 2).double().to(device);  # update this net in each optimization
    target_net = DQN(4, 300, 300, 2).double().to(device);  # fixed target net

    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()

    # update the optimizer info # 2
    optimizer = optim.RMSprop(policy_net.parameters(), lr=0.0002, alpha=0.9, eps=1e-06)
    memory = ReplayMemory(2000000)

    episode_durations = []  # add data
    # cur_net.to(device)
    # tar_net.to(device)

    num_episodes = 1000
    max_steps = 100000 # fake number for steps
    stepCounter = 0
    for i_episode in range(num_episodes):
        # set the init state
        cur_state = env.reset()

        for t in range(max_steps):
            # policy net only used to generate the experience
            cur_state = torch.tensor(cur_state, dtype=torch.double, device=device).view(1, -1)  # add batch dim

            action = policy_net.select_action(cur_state, eps)
            # interaction
            _state, reward, done, _ = env.step(action.item())

            _state = torch.tensor(_state, dtype=torch.double, device=device).view(1, -1)
            _reward = torch.tensor([reward], device=device, dtype=torch.double)

            if (t>= 199):
                print('reached the end ! :D')
                done = True
                # _reward = torch.tensor([299.0], device=device)

            if done and t < 199:
                print ('decrease reward')
                # _reward = torch.tensor([reward-299], device=device)

            if not done:
                next_state = _state
            else:
                next_state = None

            # store the transition in memory
            memory.push(cur_state, action, next_state, _reward)

            #
            cur_state = next_state

            # Perform one step of the optimization ( on the target network)

            stepCounter += 1
            if stepCounter <= target_update:
                useTargetNet = False
            else:
                useTargetNet = True
            optimize_model(memory, policy_net, target_net, optimizer, useTargetNet)

            if stepCounter % target_update == 0:
                print ('update : ')
                target_net.load_state_dict(policy_net.state_dict())

            if done:
                episode_durations.append(t + 1)

                # recent 100 durations
                print('this episode', i_episode ,' contains steps : ', t + 1)
                break

            # Update the target network, copying all weights and biases in DQN1
            pass
        pass
    print('Complete')
    plot_durations(episode_durations)
    env.render()
    env.close()
    plt.ioff()
    plt.show()
    input()
    pass


if __name__ == "__main__":
    run()
