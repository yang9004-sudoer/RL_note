# -*- coding: utf-8 -*-

import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
from itertools import count
from PIL import Image

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torchvision.transforms as T

import time


# global hyper-parameters
batch_size = 128 # bigger batch
gamma = 0.9
eps_start = 0.95
eps_end = 0.05
eps_decay = 200
target_update = 1000

# if gpu is to be used
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# set up matplotlib
is_ipython = 'inline' in matplotlib.get_backend()
if is_ipython:
    from IPython import display

plt.ion() # interactive model on

Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward'))

class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.position = 0
        self.aver = 0
        self.memory = []

    def push(self, *args):
        """Saves a transition."""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity
        pass

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)

class DQN(nn.Module):
    # update network architecture for Neural Network
    def __init__(self, state_dim, n1, n2, output_dim):
        super(DQN, self).__init__()
        # dynamic layer
        self.fc1 = nn.Linear(state_dim, n1)
        self.fc2 = nn.Linear(n1, n2)
        self.fc3 = nn.Linear(n2, output_dim)
        self.n_actions = output_dim
        self.steps_done = 0

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x) # evaluate the Q(s,a) based on
        return x # (batch, output_dim)

    def select_action(self, state):
        steps_done = self.steps_done
        sample = random.random() # sampling from [0,1]
        eps_threshold = eps_end + (eps_start - eps_end) * math.exp(-1. * steps_done / eps_decay)
        self.steps_done += 1
        if sample > eps_threshold:
            with torch.no_grad():
                # self.forward(torch.from_numpy(state).to(device)).max(1)[1].view(1, 1)
                # state_n = torch.tensor(state).float()
                acts = self.forward(state)
                # max oper -> (values, indices)
                return acts.max(1)[1].view(1, 1)
                # return self.forward(state_n)
        else:
            return torch.tensor([[random.randrange(self.n_actions)]], device=device, dtype=torch.long)

def report(fw, info):
    fw.write(str(info + "\n"))


def optimize_model(memory, policy_net, target_net, optimizer, useTarget):
    if len(memory) < batch_size:
        return
    # sampling transitions
    transitions = memory.sample(batch_size)
    batch = Transition(*zip(*transitions))

    # set the batch first as None?
    state_batch = torch.cat(batch.state)
    action_batch = torch.cat(batch.action) # size (8, 1)
    reward_batch = torch.cat(batch.reward)

    next_states_batch = torch.zeros_like(state_batch)
    for i in range(state_batch.size(0)):
        if batch.next_state[i] is not None:
            next_states_batch[i] = batch.next_state[i] #

    qValues = policy_net(state_batch) # estimate the Qvalues

    # consider the policy net output as base
    # replace it with state-action pair

    target_qValues = policy_net(state_batch).detach()
    if useTarget:
        next_target_qValues = target_net(next_states_batch).detach()
    else:
        # before certain rounds of update
        next_target_qValues = policy_net(next_states_batch).detach()

    for i in range(target_qValues.shape[0]):
        # state - action pair located
        if batch.next_state[i] is not None:
            target_qValues[i][action_batch[i]] = reward_batch[i] + \
                                            gamma * next_target_qValues[i].max(0)[0] # max
        else:
            target_qValues[i][action_batch[i]] = reward_batch[i]
    # without Final state convergence

    # print ('expected state action values : ', expected_state_action_values)
    loss = F.mse_loss(qValues, target_qValues)
    
    # final state
    # Q(final_state, *) = reward 

    # Optimize the model
    optimizer.zero_grad()
    loss.backward()
    for param in policy_net.parameters():
        param.grad.data.clamp_(-1, 1)
    optimizer.step()

    pass

def plot_durations(episode_durations):
    fig = plt.figure(2)
    plt.clf()
    durations_t = torch.tensor(episode_durations, dtype=torch.float)

    plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(durations_t.numpy())
    print ('save')
    plt.savefig('./books_read.png') # save as
    # Take 100 episode averages and plot them too
    if len(durations_t) >= 100:
        means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
        means = torch.cat((torch.zeros(99), means))
        plt.plot(means.numpy())

    plt.pause(0.1)  # pause a bit so that plots are updated
    if is_ipython:
        display.clear_output(wait=True)
        display.display(plt.gcf())


def plot_value(sample_Qsa_1, sample_Qsa_2):
    plt.figure(3)
    plt.clf()
    sample_Qsa_1_tensor = torch.tensor(sample_Qsa_1, dtype=torch.float)
    sample_Qsa_2_tensor = torch.tensor(sample_Qsa_2, dtype=torch.float)

    plt.title('Training...')
    plt.xlabel('Step')
    plt.ylabel('Value')
    plt.plot(sample_Qsa_1_tensor.numpy())
    plt.plot(sample_Qsa_2_tensor.numpy())

    plt.pause(0.1)  # pause a bit so that plots are updated
    if is_ipython:
        display.clear_output(wait=True)
        display.display(plt.gcf())


def run():

    # setup the report file
    # fo = open("report_" + time.asctime().replace(" ", "_") + ".txt", "w")
    # environment control
    env = gym.make('CartPole-v0').unwrapped
    # report(fo, 'CartPole-v0')

    # display setup
    is_ipython = 'inline' in matplotlib.get_backend()
    if is_ipython:
        from IPython import display
    plt.ion()

    # training ()
    # create an current Q-networks
    # create an target Q-networks
    #
    policy_net = DQN(4, 300, 300, 2).to(device); # update this net in each optimization
    target_net = DQN(4, 300, 300, 2).to(device); # fixed target net

    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()

    optimizer = optim.Adam(policy_net.parameters(), lr=0.01)
    memory = ReplayMemory(1000000)

    episode_durations = [] # add data
    sample_Qsa_1 = [] # Sample a speific Qsa
    sample_Qsa_2 = []  # Sample a speific Qsa
    episode_sample_Qsa_duraions = []
    # cur_net.to(device)
    # tar_net.to(device)

    num_episodes = 1000
    stepCounter = 0
    maxStep = 200
    sample_S = None
    sample_point = 0

    for i_episode in range(num_episodes):
        # set the init state
        cur_state = env.reset()

        for t in count():
            #policy net only used to generate the experience
            cur_state = torch.tensor(cur_state ,dtype=torch.float, device=device).view(1, -1) # add batch dim

            if t == sample_point and sample_S is None:
            # sampling a specific state
                sample_S = cur_state
            if sample_S is not None:
                # print ('pick a specific state : ', sample_S.cpu().numpy())
                if stepCounter >= target_update: # using targetnet
                    sample_S_Qsa = target_net(sample_S).detach()
                else:
                    sample_S_Qsa = policy_net(sample_S).detach()
                sample_S_Qsa = sample_S_Qsa.cpu().numpy()
                # print ('sample S Qsa : ' , sample_S_Qsa)


            action = policy_net.select_action(cur_state)
            # interaction
            _state, reward, done, _ = env.step(action.item())

            _state = torch.tensor(_state, dtype=torch.float, device=device).view(1, -1)
            reward = torch.tensor([reward], device=device)

            if t >= maxStep:
                done = True
                # reward = torch.tensor([float(t)-maxStep], device=device)
            if t < maxStep and done:
                # reward = torch.tensor([float(t)-maxStep], device=device)
                pass
            if not done:
                next_state = _state
            else:
                next_state = None

            # store the transition in memory
            memory.push(cur_state, action, next_state, reward)
            #
            cur_state = next_state

            # Perform one step of the optimization ( on the target network)
            stepCounter+= 1
            if stepCounter % target_update == 0:
                print('### use target net .... ! ')
                target_net.load_state_dict(policy_net.state_dict())

            if stepCounter >= target_update:
                optimize_model(memory, policy_net, target_net, optimizer, True)
            else:
                optimize_model(memory, policy_net, target_net, optimizer, False)

            if done:
                episode_durations.append(t + 1)

                if sample_S is not None and stepCounter >= target_update:
                    print ('sample_Qsa : ',sample_S_Qsa )
                    sample_Qsa_1.append(sample_S_Qsa[0][0])
                    sample_Qsa_2.append(sample_S_Qsa[0][1])
                else:
                    sample_Qsa_1.append(0.0)
                    sample_Qsa_2.append(0.0)


                # recent 100 durations
                print (' episode-' , i_episode , ' contains steps : ', t+1)
                plot_durations(episode_durations)
                plot_value(sample_Qsa_1, sample_Qsa_2)
                ###########3 Important ! ############
                # stop update network after get certain performance like
                # recent 100 episodes achieve 200 points
                # otherwise it may lead to overfitting !
                break

            # Update the target network, copying all weights and biases in DQN1

        pass
    print('Complete')

    env.render()
    env.close()
    plt.ioff()
    plt.show()
    input()
    pass


if __name__ == "__main__":
    run()
