import torch
import numpy as np
import torch.nn as nn
import gym
from torch.distributions.categorical import Categorical
import torch.optim as optim
import torch.nn.functional as F
import matplotlib.pyplot as plt


class ActorCritic(nn.Module): # 2 heads
    def __init__(self, input_dim, layers_dims, output_dim):
        super(ActorCritic, self).__init__()
        self.layers = []
        self.layers.append(input_dim)
        self.layers.extend(layers_dims)
        for i in range(len(self.layers) - 1):
            name = 'fc' + str(i)
            # add to named children modules
            self.add_module(name, nn.Linear(self.layers[i], self.layers[i + 1]))

        actor_output = output_dim[0]
        critic_output = output_dim[1]
        self.add_module('actor_output', nn.Linear(self.layers[-1], actor_output))
        self.add_module('critic_output', nn.Linear(self.layers[-1], critic_output))

    def forward(self, x):
        # for loop in neural network structure
        for layer in list(self.children())[:-2]:
            x = torch.relu(layer(x))
        # for last output using softmax and logit ?
        actor_head = list(self.children())[-2]
        critic_head = list(self.children())[-1]
        actor_probs = F.softmax(actor_head(x))
        value = critic_head(x)
        return (actor_probs, value)



def update(gamma, device, ep_actions_logprob, ep_rewards,
           ep_values, actor_critic_optimizer):
    R = 0  # the Gt as discounted return
    # ep_actions_logprob
    policy_loss = []
    value_loss = []
    returns = []

    for r in ep_rewards[::-1]:
        R = r + gamma * R
        returns.insert(0, R)

    returns = torch.tensor(returns, device=device)
    eps = np.finfo(np.float32).eps.item()  # Machine limits for floating
    # point types. the most smallest float number in this machine
    returns = (returns - returns.mean()) / (returns.std() + eps)

    for log_prob, value, Re in zip(ep_actions_logprob, ep_values, returns):
        adv = Re - value.item()  # monte carlo(0)
        # TD version
        #
        # adv = r + gamma* critic(obs_next) - critic(obs)
        #
        policy_loss.append(-log_prob * adv)
        value_loss.append(F.smooth_l1_loss(value, torch.tensor(Re)))
        pass

    actor_critic_optimizer.zero_grad()


    # sum up all the actor_loss and critic_loss or using mean()
    actor_loss = torch.stack(policy_loss).sum()
    critic_loss = torch.stack(value_loss).sum()
    total_loss = actor_loss + critic_loss

    # perform backprop
    total_loss.backward()
    # gradient update
    actor_critic_optimizer.step()


    # reset rewards and action buffer

    pass

def plot_durations(episode_durations, exp_num):
    fig = plt.figure(2)
    plt.clf()
    durations_t = torch.tensor(episode_durations, dtype=torch.float)

    plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(durations_t.numpy())
    print ('save')

    # Take 100 episode averages and plot them too
    if len(durations_t) >= 100:
        means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
        means = torch.cat((torch.zeros(99), means))
        plt.plot(means.numpy())
    figname = './training_episode_' + str(exp_num) +  '.png'
    plt.savefig(figname) # save as


def run(run_idx):
    # device
    device = device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    maxstep = 200
    env = gym.make('CartPole-v0')

    action_dim = env.action_space.n
    obs_dim = env.observation_space.shape[0]
    actor_critic = ActorCritic(obs_dim, [30, 30], [action_dim, 1]).to(device)

    print(list(actor_critic.named_children()))
    # [('fc0', Linear(in_features=4, out_features=30, bias=True)),
    #  ('fc1', Linear(in_features=30, out_features=30, bias=True)),
    #  ('actor_output', Linear(in_features=30, out_features=2, bias=True)),
    #  ('critic_output', Linear(in_features=30, out_features=1, bias=True))]

    actor_critic_optimizer = optim.Adam(actor_critic.parameters(), lr=1e-2)
    gamma = 0.9
    winning_cond = 195

    # # each episode udpate for
    max_episodes = 8000
    episodes_steps = []

    for ei in range(max_episodes):

        ep_states = []
        ep_rewards = []
        ep_actions_logprob = []
        ep_values = []

        # reset for each episode
        obs = env.reset()  # first observation
        epi_step = 0


        while True:
            obs = torch.tensor(obs, dtype=torch.float32,
                         device=device)
            ep_states.append(obs)

            # based on observation sample an action
            act_probs, value = actor_critic(obs)

            dist = Categorical(act_probs)
            action = dist.sample()
            action_logprob = dist.log_prob(action)

            # based on observation get a value based VF
            ep_values.append(value)

            obs, rew, done, _ = env.step(action.item())
            epi_step += 1

            ep_rewards.append(rew)
            ep_actions_logprob.append(action_logprob)

            if epi_step >= maxstep:
                done = True

            if done:
                break

        pass
        episodes_steps.append(epi_step)

        # after single episode is finish
        # update(gamma, device, ep_actions_logprob, ep_rewards,
        #            ep_values, actor_optimizer, critic_optimizer)

        update(gamma, device, ep_actions_logprob,
               ep_rewards, ep_values, actor_critic_optimizer)

        print ('Episode ', ei, ' rewards : ' , epi_step,
               ' average rewards : ', np.mean(episodes_steps[-100:]))
        running_reward = np.mean(episodes_steps[-100:])
        if running_reward > winning_cond:
            print ('Sovled ! Running reward is now : ' , running_reward)
            break

    plot_durations(episodes_steps, run_idx)


    pass


if __name__ == '__main__':
    for r in range(100):
        run(r)

