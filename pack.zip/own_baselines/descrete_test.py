import random


# using discrete env to simulate the CartPole-v0
class Env(object):

    ### [(0) , 1, 2, 3, 4, 5 , (6)] [0,6] are the terminations status
    def __init__(self):
        self.state = None
        pass

    def reset(self):
        self.state = random.randint(1, 5)
        return self.state

    def step(self, action):
        pass

def env():
    pass


def run():
    pass

if __name__ == '__main__':
    random.randint(1, 5)
    run()