


res = [i for i in range(5)]
res.reverse()
print (res)
ws = []
wst = []

for i in res:
    ws = [w*0.5 for w in ws]
    ws.insert(0, i)
    wst.insert(0, sum(ws))
    print (ws)
    pass

print ('wst:')
print (wst)